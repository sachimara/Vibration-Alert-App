package com.example.vibrationalert;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;

import com.example.vibrationalert.databinding.FragmentFirstBinding;

public class VibrstionAlert extends Fragment {

    private FragmentFirstBinding binding;
    private TextView showAlertTextView;
    private TextView vibrationInputTextView;

  //  @Override
  //  public View onCreateView(
  //          LayoutInflater inflater, ViewGroup container,
  //          Bundle savedInstanceState
  //  ) {
//
  //      binding = FragmentFirstBinding.inflate(inflater, container, false);
  //      return binding.getRoot();
//
  //  }
    @Override
    public View onCreateView(
            LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState
    ) {
        binding = FragmentFirstBinding.inflate(inflater, container, false);
        // Inflate the layout for this fragment
        View fragmentFirstLayout = inflater.inflate(R.layout.fragment_first, container, false);
        // Get the count text view
        showAlertTextView = fragmentFirstLayout.findViewById(R.id.textView2);
        vibrationInputTextView = fragmentFirstLayout.findViewById(R.id.editTextNumberDecimal2);
        return fragmentFirstLayout;
        //return binding.getRoot();
    }

    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        //binding.detailButton.setOnClickListener(new View.OnClickListener() {
        view.findViewById(R.id.detail_button).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                NavHostFragment.findNavController(VibrstionAlert.this)
                        .navigate(R.id.action_FirstFragment_to_SecondFragment);
            }
        });

        //view.findViewById(R.id.alert_button).setOnClickListener(new View.OnClickListener() {
//        view.findViewById(R.id.editTextNumberDecimal2).onKeyPreIme()OnEditorActionListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//
//                doAlert(view);
//            }
//        });

        view.findViewById(R.id.editTextNumberDecimal2).setOnKeyListener(new View.OnKeyListener() {
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if (KeyEvent.KEYCODE_ENTER == keyCode)
                {
                    //Intent setupIntent = new Intent(getApplicationContext(),SetUp.class);
                    doAlert(view);
                    return true;
                } else {
                    return false;
                }
            }
        });


    }
    private void doAlert(View view) {
        ImageView iv = (ImageView)view.findViewById(R.id.imageView2);
        //iv.setVisibility(View.GONE);
        //iv.setImageDrawable(R.drawable.abc_ic_star_black_16dp);

        String vibationValStr = vibrationInputTextView.getText().toString();
        Double vibrationVal = Double.parseDouble(vibationValStr);
        String alrtTxt = "Not Uncomfortable";
        PorterDuff.Mode mode = PorterDuff.Mode.SRC_ATOP;
        //Tafficlight colours https://www.schemecolor.com/traffic-signal-colors.php
        int tintGreen = Color.parseColor("#4CBB17");
        //int tintAmber = Color.parseColor("#FF7800");
        int tintAmber = Color.parseColor("#FFFFC107");
        int tintRed = Color.parseColor("#E60000");
        if(vibrationVal < 0.315) {
            alrtTxt = "Not Uncomfortable";
            iv.getDrawable().setColorFilter(tintGreen, PorterDuff.Mode.SRC);
        } else if(vibrationVal < 0.5) {
            alrtTxt = "A Little Uncomfortable";
           // iv.getDrawable().setColorFilter(Color.GREEN, PorterDuff.Mode.SRC);
            iv.getDrawable().setColorFilter(tintGreen, PorterDuff.Mode.SRC);
        } else if(vibrationVal < 0.63) {
            alrtTxt = "Can be A Little to Fairly Uncomfortable";
            iv.getDrawable().setColorFilter(tintAmber, PorterDuff.Mode.SRC);
        }else if(vibrationVal < 0.8) {
            alrtTxt = "Fairly Uncomfortable";
            iv.getDrawable().setColorFilter(tintAmber, PorterDuff.Mode.SRC);
        }else if(vibrationVal < 1.0) {
           alrtTxt = "Can be Fairly Uncomfortable to Uncomfortable";
            iv.getDrawable().setColorFilter(tintAmber, PorterDuff.Mode.SRC);
        }else if(vibrationVal < 1.25) {
            alrtTxt = "Uncomfortable";
            iv.getDrawable().setColorFilter(tintAmber, PorterDuff.Mode.SRC);
        }else if(vibrationVal < 1.6) {
            alrtTxt = "Can be Uncomfortable to Very Uncomfortable";
            iv.getDrawable().setColorFilter(tintRed, PorterDuff.Mode.SRC);
        }else if(vibrationVal < 2.0) {
            alrtTxt = "Very Uncomfortable";
            iv.getDrawable().setColorFilter(tintRed, PorterDuff.Mode.SRC);
        }else if(vibrationVal < 2.5) {
            alrtTxt = "Can be Very to Extremely Uncomfortable";
            iv.getDrawable().setColorFilter(tintRed, PorterDuff.Mode.SRC);
        } else  {
            alrtTxt = "Extremely Uncomfortable";
            iv.getDrawable().setColorFilter(tintRed, PorterDuff.Mode.SRC);
        }
        showAlertTextView.setText(alrtTxt);
        //vibrationInputTextView.setText("0.0");
    }
    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

}